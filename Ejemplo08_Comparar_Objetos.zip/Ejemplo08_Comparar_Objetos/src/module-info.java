module Ejemplo08_Comparar_Objetos {
}
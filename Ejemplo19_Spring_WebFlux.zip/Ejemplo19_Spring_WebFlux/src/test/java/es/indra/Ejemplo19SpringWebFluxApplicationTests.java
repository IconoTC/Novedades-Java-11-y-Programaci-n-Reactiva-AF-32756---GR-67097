package es.indra;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ejemplo19SpringWebFluxApplicationTests {

	@Test
	void contextLoads() {
	}

}

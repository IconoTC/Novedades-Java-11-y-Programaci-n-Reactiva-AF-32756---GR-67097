package es.indra;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.Scanner;

import org.json.JSONArray;
import org.json.JSONObject;

public class AppMain {

	public static void main(String[] args) throws URISyntaxException, IOException, InterruptedException {
		
		String url = "https://pokeapi.co/api/v2/pokemon/";
		
		URI uri = new URI(url);
		HttpRequest request = HttpRequest.newBuilder(uri).GET().build();
		
		HttpClient client = HttpClient.newHttpClient();
		
		HttpResponse<String> respuesta = client.send(request, HttpResponse.BodyHandlers.ofString());
		//System.out.println(respuesta.body());
		
		JSONObject jsonObject = new JSONObject(respuesta.body());
		//JSONArray jsonArray = new JSONArray(jsonObject.get("results").toString());
		JSONArray jsonArray = new JSONArray(jsonObject.getJSONArray("results"));
		
		System.out.println("--------Lista de los pokemons-------");
		for (Object object : jsonArray) {
			JSONObject pokemon = new JSONObject(object.toString());
			System.out.println(pokemon.getString("name"));
		}
		
		/*    Buscar un pokemon */		
		Scanner sc = new Scanner(System.in);
		System.out.println("Introduce el nombre del Pokemon:");
		String nombre = sc.next();
		
		uri = new URI(url + nombre);
		request = HttpRequest.newBuilder(uri).GET().build();
		respuesta = client.send(request, HttpResponse.BodyHandlers.ofString());
		System.out.println(respuesta.body());
		
		jsonObject = new JSONObject(respuesta.body());
		
		System.out.println("ID:" + jsonObject.getInt("id"));
		System.out.println("Nombre:" + jsonObject.getString("name"));
		System.out.println("Order:" + jsonObject.getInt("order"));
		System.out.println("Altura:" + jsonObject.getInt("height"));
		System.out.println("Peso:" + jsonObject.getInt("weight"));
		
		JSONArray habilidades = new JSONArray(jsonObject.getJSONArray("abilities"));
		System.out.print("Habilidades:");
		for (Object object : habilidades) {
			JSONObject jsonHabilidad = new JSONObject(object.toString());
			JSONObject habilidad = jsonHabilidad.getJSONObject("ability");
			System.out.print(habilidad.getString("name") + " ");
		}
		System.out.println();

	}

}










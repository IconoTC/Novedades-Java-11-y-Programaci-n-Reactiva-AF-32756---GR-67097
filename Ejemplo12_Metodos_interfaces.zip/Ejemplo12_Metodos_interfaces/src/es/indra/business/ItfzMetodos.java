package es.indra.business;

public interface ItfzMetodos {
	
	// A partir de Java 8: metodos estaticos y default
	public static void estatico() {
		System.out.println("Metodo estatico");
		
		// Desde un metodo estatico solo puedes acceder a recursos estaticos
		
	}
	
	public default void defecto() {
		System.out.println("Metodo defecto");	
	}
	
	// A partir de Java 11: metodos privados
	private String mayusculas(String texto) {
		return texto.toUpperCase();
	}
	
	private String minusculas(String texto) {
		return texto.toLowerCase();
	}
	
	// La unica forma que tenemos de acceder a los metodos privados
	// es desde metodos default en la misma interface donde se han declarado
	public default String procesarTexto(String texto) {
		return "Mayusculas: " + mayusculas(texto) + "\n" +
				"Minusculas: " + minusculas(texto);
	}

}

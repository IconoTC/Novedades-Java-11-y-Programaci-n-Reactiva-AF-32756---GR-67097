package es.indra;

import java.util.Optional;

import es.indra.models.Producto;
import es.indra.persistence.ProductosDAO;

public class AppMain {

	public static void main(String[] args) {
		
		ProductosDAO dao = new ProductosDAO();
		
		// Buscar un producto que existe
		System.out.println(dao.buscarProducto(3).get());
		
		// Buscar un producto que NO existe
		// java.util.NoSuchElementException: No value present
		// System.out.println(dao.buscarProducto(333333).get());
		
		// 1ª forma de evitar esa excepcion
		System.out.println(dao.buscarProducto(333333).orElse(new Producto())  );
		
		
		// 2ª forma de evitar la excepcion
		Optional<Producto> opProd = dao.buscarProducto(333333);
		if (opProd.isPresent()) {
			System.out.println(opProd.get());
		} else {
			System.out.println("Producto no existente");
		}
		
		// 3ª forma de evitar la excepcion
		opProd = dao.buscarProducto(333333);
		if (opProd.isEmpty()) {
			System.out.println("Producto no existente");		
		} else {
			System.out.println(opProd.get());
		}
		
		// Quiero lanzar una excepcion en el caso de que no exista el producto
		// java.util.NoSuchElementException: No value present
		//System.out.println(opProd.orElseThrow());
		
		// java.lang.RuntimeException: Producto no encontrado
		//System.out.println(opProd.orElseThrow( () -> new RuntimeException("Producto no encontrado")   ));
		
		opProd = dao.buscarProducto(1);
		opProd.stream()
			.map(p -> p.getDescripcion().toUpperCase())
			.forEach(System.out::println);
		

	}

}

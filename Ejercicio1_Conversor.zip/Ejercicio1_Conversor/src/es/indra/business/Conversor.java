package es.indra.business;

public class Conversor {
	
	public double dollarToEuro(double dolares) {
		return dolares * 0.94;
	}
	
	public double euroToDollar(double euros) {
		return euros / 0.94;
	}

}

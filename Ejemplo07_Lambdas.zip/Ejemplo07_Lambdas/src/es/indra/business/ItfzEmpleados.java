package es.indra.business;

@FunctionalInterface
public interface ItfzEmpleados {
	
	// Debe tener un solo metodo abstracto
	public abstract String detalle(String nombre, int edad);

}

package es.indra.business;

import java.util.concurrent.SubmissionPublisher;
import java.util.concurrent.Flow;
import java.util.concurrent.Flow.Subscription;

public class Publicador extends SubmissionPublisher<Integer> implements Flow.Processor<Integer, Integer>{
	
	private Flow.Subscription subscription;

	@Override
	public void onSubscribe(Subscription subscription) {
		this.subscription = subscription;
		subscription.request(1);
	}

	@Override
	public void onNext(Integer item) {
		// publicar el mensaje
		submit(item);
		System.out.println("Mensaje enviado: " + item);
		subscription.request(1);
	}

	@Override
	public void onError(Throwable error) {
		// Mostrar el error en la consola
		error.printStackTrace();
	}

	@Override
	public void onComplete() {
		System.out.println("Publicador ha terminado");
		close();
	}

}

package es.indra;

import es.indra.models.Direccion;
import es.indra.models.Empleado;

public class AppMain {

	public static void main(String[] args) {
		
		Direccion direccion = new Direccion("Diagonal", 149, "Barcelona");
		Empleado empleado = new Empleado(1, "Manuel", 47000, direccion);
		
		System.out.println(empleado);

	}

}



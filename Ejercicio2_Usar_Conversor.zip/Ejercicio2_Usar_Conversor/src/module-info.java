/**
 * 
 */
/**
 * 
 */
module Ejercicio2_Usar_Conversor {
	
	// requires nombre_modulo
	requires Ejercicio1_Conversor;
}
/**
 * 
 */
/**
 * 
 */
module Ejemplo13_Logging {
	
	requires java.logging;
}
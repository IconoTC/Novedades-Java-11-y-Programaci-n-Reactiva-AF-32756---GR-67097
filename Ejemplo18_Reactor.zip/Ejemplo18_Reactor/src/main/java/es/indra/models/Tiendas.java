package es.indra.models;

import java.util.ArrayList;
import java.util.List;

public class Tiendas {
	
	private List<String> tiendas = new ArrayList<>();
	
	public void addTienda(String tienda) {
		tiendas.add(tienda);
	}
	
	public List<String> getTiendas() {
		return tiendas;
	}

	@Override
	public String toString() {
		return "Tiendas [tiendas=" + tiendas + "]";
	}
	
}

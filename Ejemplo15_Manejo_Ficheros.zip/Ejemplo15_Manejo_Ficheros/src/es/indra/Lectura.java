package es.indra;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

public class Lectura {

	public static void main(String[] args) {
		
		Path path = Paths.get("texto.txt");
		
		try {
			// 1ª forma - leer todo el contenido en una variable String
			String contenido = Files.readString(path);
			System.out.println(contenido);
			
			// 2ª forma - leer todo el contenido en una lista
			List<String> lineas = Files.readAllLines(path);
			lineas.stream()
				.map(linea -> linea.toUpperCase())
				.forEach(System.out::println);
			
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}

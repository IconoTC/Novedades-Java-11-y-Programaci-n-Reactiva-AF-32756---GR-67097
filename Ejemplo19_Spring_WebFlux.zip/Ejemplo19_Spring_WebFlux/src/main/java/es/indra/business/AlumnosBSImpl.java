package es.indra.business;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import es.indra.models.Alumno;
import es.indra.persistence.AlumnosDAO;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
public class AlumnosBSImpl implements AlumnosBS{
	
	@Autowired
	private AlumnosDAO dao;

	@Override
	public Flux<Alumno> consultarTodos() {
		return dao.todos();
	}

	@Override
	public Mono<Alumno> buscarAlumno(int id) {
		return dao.buscar(id);
	}

	@Override
	public Mono<Alumno> crearNuevo(Alumno alumno) {
		return dao.crearNuevo(alumno);
	}

	@Override
	public Mono<Void> eliminarAlumno(int id) {
		return dao.eliminar(id);
	}

	@Override
	public Mono<Alumno> modificarAlumno(Alumno alumno) {
		return dao.modificar(alumno);
	}

}

module Ejemplo07_Lambdas {
}
package es.indra;

import java.util.Arrays;
import java.util.List;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import es.indra.models.Producto;
import es.indra.models.ProductoTiendas;
import es.indra.models.Tiendas;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@SpringBootApplication
public class Ejemplo18ReactorApplication implements CommandLineRunner{
	
	List<Producto> lista = Arrays.asList(
			new Producto(1, "Pantalla", 129.95),
			new Producto(2, "Teclado", 53.29),
			new Producto(3, "Raton", 19.50));

	public static void main(String[] args) {
		SpringApplication.run(Ejemplo18ReactorApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		combinar_flujos_flatMap();
	}
	
	public void combinar_flujos_flatMap() {
		// Crear un Mono de 1 producto
		Mono<Producto> productoMono = Mono.just(new Producto(1, "Pantalla", 129.95));
		
		// Crear un Mono de tiendas
		Mono<Tiendas> tiendasProductoMono = Mono.fromCallable(() -> {
			Tiendas tiendas = new Tiendas();
			tiendas.addTienda("PC Components");
			tiendas.addTienda("Amazon");
			tiendas.addTienda("Media Mark");
			return tiendas;
		});
		
		// Combinar flujos
		productoMono.flatMap(prod -> tiendasProductoMono.map(tiendas -> new ProductoTiendas(prod, tiendas)))
		    .subscribe(resultado -> {
		    	System.out.println("El producto: " + resultado.getProducto());
		    	System.out.println("Se vende en: ");
		    	resultado.getTiendas().getTiendas().forEach(System.out::println);
		    });
		
	}
	
	public void convertir_flux_mono() {
		Flux.fromIterable(lista)
			.collectList()   // retorna Mono<List<Producto>>
			.subscribe(listaProd -> System.out.println(listaProd));   // Muestra la lista entera
		
		Flux.fromIterable(lista)
			.collectList()   // retorna Mono<List<Producto>>
			.subscribe(listaProd -> listaProd.forEach(System.out::println));
	}
	
	public void operador_flatMap() {
		// El operador map no es reactivo
		// la alternativa es utilizar flatMap.
		// flatMap modifica el elemento y lo devuelve al stream como reactivo (Flux o Mono)
		Flux.fromIterable(lista)
			.flatMap(prod -> {
				if (prod.getDescripcion().equals("Raton")) {
					return Mono.just(prod);
				} else {
					return Mono.empty();
				}			
			})
			.doOnNext(System.out::println)
			.subscribe();
	}
	
	public void complete() {
		// Mostrar los datos por consola y un mensaje final
		// Opcion 1
		Flux.just("Ana", "Juan", "Pedro", "Olivia")
				.doOnNext(dato -> System.out.println(dato))
				.doOnComplete(new Runnable() {
					
					@Override
					public void run() {
						System.out.println("-----  FIN  -----");
						
					}
				})
				.subscribe();
		
		// Opcion 2
		Flux.just("Ana", "Juan", "Pedro", "Olivia")
			.doOnNext(dato -> System.out.println(dato))
			.doOnComplete(() -> System.out.println("-----  FIN  -----"))
			.subscribe();
		
		// Opcion 3
		Flux.just("Ana", "Juan", "Pedro", "Olivia")
			.subscribe(dato -> System.out.println(dato), 
					   error -> System.out.println(error), 
					   () -> System.out.println("-----  FIN  -----"));		
	}
	
	public void crear_Flux_Iterable() {
		// OJO!! los arrays no son iterables
		Flux.fromIterable(lista)
			.filter(p -> p.getPrecio() > 50)
			.map(p -> {
				p.setDescripcion(p.getDescripcion().toUpperCase());
				return p;
			})
			.doOnNext(System.out::println)
			.subscribe();
	}
	
	public void manejoError() {
		// Flux es un flujo de varios elementos
		Flux<String> datos = Flux.just("Ana", "Juan", "", "Pedro", "Olivia")
				.doOnNext(dato -> {
					if (dato.isEmpty()) {
						throw new RuntimeException("Dato vacio");
					}
					System.out.println(dato);
				});
		
		// Hasta que no se subscribe al flujo, no hace nada
		datos.subscribe();
	}
	
	public void crearFlux() {
		// Flux es un flujo de varios elementos
		Flux<String> datos = Flux.just("Ana", "Juan", "Pedro", "Olivia")
				.doOnNext(dato -> System.out.println(dato));
		
		// Hasta que no se subscribe al flujo, no hace nada
		datos.subscribe();
	}
	
	public void crearMono() {
		// Mono es un flujo con un solo elemento
		Mono<String> mono = Mono.just("Mi primer flujo con reactor");
		mono.subscribe(System.out::println);
	}

}

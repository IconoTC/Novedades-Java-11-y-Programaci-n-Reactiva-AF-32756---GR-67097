/**
 * 
 */
/**
 * 
 */
module Ejemplo03_Servicio_Interface {
	
	// exports paquete
	exports es.indra.interfaz;
}
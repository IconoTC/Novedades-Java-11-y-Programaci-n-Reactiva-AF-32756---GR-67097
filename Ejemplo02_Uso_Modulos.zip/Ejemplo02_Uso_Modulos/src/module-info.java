/**
 * 
 */
/**
 * 
 */
module Ejemplo02_Uso_Modulos {
	
	// Para poder utilizar el modulo de otro proyecto
	// es necesario agregarlo en el Module Path
	
	// requires nombre_modulo
	requires Ejemplo01_Crear_Modulo;
}
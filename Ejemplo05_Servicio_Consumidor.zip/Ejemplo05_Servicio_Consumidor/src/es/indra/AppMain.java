package es.indra;

import java.util.ServiceLoader;
import java.util.stream.StreamSupport;

import es.indra.interfaz.ItfzSaludo;

public class AppMain {

	public static void main(String[] args) {
		
		ServiceLoader<ItfzSaludo> loader = ServiceLoader.load(ItfzSaludo.class);
		Iterable<ItfzSaludo> iterable = () -> loader.iterator();
		ItfzSaludo saludo = StreamSupport.stream(iterable.spliterator(), false)
								.findFirst()
								.get();
		
		System.out.println(saludo.saludar());

	}

}

package es.indra;

import java.util.Arrays;
import java.util.List;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import es.indra.models.Producto;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@SpringBootApplication
public class Ejemplo18ReactorApplication implements CommandLineRunner{

	public static void main(String[] args) {
		SpringApplication.run(Ejemplo18ReactorApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		crear_Flux_Iterable();
	}
	
	public void crear_Flux_Iterable() {
		// OJO!! los arrays no son iterables
		List<Producto> lista = Arrays.asList(
				new Producto(1, "Pantalla", 129.95),
				new Producto(2, "Teclado", 53.29),
				new Producto(3, "Raton", 19.50));
		
		Flux.fromIterable(lista)
			.filter(p -> p.getPrecio() > 50)
			.map(p -> {
				p.setDescripcion(p.getDescripcion().toUpperCase());
				return p;
			})
			.doOnNext(System.out::println)
			.subscribe();
	}
	
	public void manejoError() {
		// Flux es un flujo de varios elementos
		Flux<String> datos = Flux.just("Ana", "Juan", "", "Pedro", "Olivia")
				.doOnNext(dato -> {
					if (dato.isEmpty()) {
						throw new RuntimeException("Dato vacio");
					}
					System.out.println(dato);
				});
		
		// Hasta que no se subscribe al flujo, no hace nada
		datos.subscribe();
	}
	
	public void crearFlux() {
		// Flux es un flujo de varios elementos
		Flux<String> datos = Flux.just("Ana", "Juan", "Pedro", "Olivia")
				.doOnNext(dato -> System.out.println(dato));
		
		// Hasta que no se subscribe al flujo, no hace nada
		datos.subscribe();
	}
	
	public void crearMono() {
		// Mono es un flujo con un solo elemento
		Mono<String> mono = Mono.just("Mi primer flujo con reactor");
		mono.subscribe(System.out::println);
	}

}

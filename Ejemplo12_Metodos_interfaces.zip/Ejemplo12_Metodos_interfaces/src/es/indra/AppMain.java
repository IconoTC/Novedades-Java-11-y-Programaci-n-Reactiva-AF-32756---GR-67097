package es.indra;

import es.indra.business.ItfzMetodos;

public class AppMain {

	public static void main(String[] args) {
		
		// Los recursos estaticos no necesitan instancias
		ItfzMetodos.estatico();
		new ItfzMetodos() {
		}.defecto();
		
		// No tenemos acceso a los metodos privados de la interface
		//ItfzMetodos.mayusculas("Hola");
//		new ItfzMetodos() {
//		}.mayusculas("Hola");
		
		ItfzMetodos obj = new ItfzMetodos() {
		};
		System.out.println(obj.procesarTexto("Necesito un café"));

	}

}

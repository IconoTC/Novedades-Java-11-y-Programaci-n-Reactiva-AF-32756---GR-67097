package es.indra;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.web.reactive.function.client.WebClient;

import es.indra.cliente.AccesoREST;
import es.indra.models.Alumno;

@SpringBootApplication
public class Ejemplo20ClienteReactivoApplication implements CommandLineRunner{
	
	
	@Autowired
	private AccesoREST accesoREST;
	
	// En Spring como cliente de un servicio REST podemos utilizar:
	//     - RestTemplate, pertenece a Spring MVC
	//     - Feign, pertenece a Spring Cloud
	// Ninguno de los 2 es reactivo.
	
	// En programacion reactiva, utilizamos WebClient, pertenece a Spring WebFlux
	
	
	
	@Override
	public void run(String... args) throws Exception {
		accesoREST.crearNuevo(new Alumno(5, "Pepito", "Perez", 7.3))
			.subscribe(item -> System.out.println("Alumno creado " + item));
		
		accesoREST.consultarTodos()
			.subscribe(System.out::println);
		
	}

	public static void main(String[] args) {
		SpringApplication.run(Ejemplo20ClienteReactivoApplication.class, args);
	}

	

}

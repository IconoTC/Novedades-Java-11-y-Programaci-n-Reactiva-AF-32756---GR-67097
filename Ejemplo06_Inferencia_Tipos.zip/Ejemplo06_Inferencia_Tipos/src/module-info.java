module Ejemplo06_Inferencia_Tipos {
}
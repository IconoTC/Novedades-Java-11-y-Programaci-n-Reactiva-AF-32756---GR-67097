/**
 * 
 */
/**
 * 
 */
module Ejemplo04_Servicio_Proveedor {
	
	// Necesito el modulo donde tengo la interface
	requires Ejemplo03_Servicio_Interface;
	
	// Proporcionamos una clase que implementa la interface
	provides es.indra.interfaz.ItfzSaludo with es.indra.business.Saludo;
}
/**
 * 
 */
/**
 * 
 */
module Ejemplo12_Metodos_interfaces {
}
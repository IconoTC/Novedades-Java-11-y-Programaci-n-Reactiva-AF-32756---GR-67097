package es.indra;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

import org.json.JSONArray;
import org.json.JSONObject;

public class AppMain {

	public static void main(String[] args) throws URISyntaxException, IOException, InterruptedException {
		
		String url = "https://jsonplaceholder.typicode.com/users";
		
		// Preparar la peticion
		URI uri = new URI(url);
		HttpRequest request = HttpRequest.newBuilder(uri).GET().build();
		
		// Contenedor cliente
		HttpClient client = HttpClient.newHttpClient();
		
		// Enviar la peticion y recibimos la respuesta
		HttpResponse<String> respuesta = client.send(request, HttpResponse.BodyHandlers.ofString());
		//System.out.println(respuesta.body());
		
		// Convertir ese String en un array de JSON
		JSONArray jsonArray = new JSONArray(respuesta.body());
		
		// Recorrer el array y por cada objeto generar un objeto JSON
		for (Object object : jsonArray) {
			JSONObject usuario = new JSONObject(object.toString());
			
			// Mostrar los datos del usuario
			System.out.println("ID: " + usuario.getInt("id"));
			System.out.println("Nombre: " + usuario.getString("name"));
			System.out.println("Usuario: " + usuario.getString("username"));
			System.out.println("Email: " + usuario.getString("email"));
			
			JSONObject direccion = usuario.getJSONObject("address");
			System.out.println("Calle: " + direccion.getString("street"));
			System.out.println("Numero: " + direccion.getString("suite"));
			System.out.println("Ciudad: " + direccion.getString("city"));
			System.out.println("Codigo Postal: " + direccion.getString("zipcode"));
			
			JSONObject coordenadas = direccion.getJSONObject("geo");
			System.out.println("Latitud: " + coordenadas.getString("lat"));
			System.out.println("Longitud: " + coordenadas.getString("lng"));
			
			System.out.println("---------------------------------");
		}

	}

}

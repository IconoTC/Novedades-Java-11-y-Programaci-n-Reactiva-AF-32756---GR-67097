/**
 * 
 */
/**
 * 
 */
module Ejemplo01_Crear_Modulo {
	
	// exports paquete
	exports es.indra.models;
}
package es.indra;

import java.util.ServiceLoader;
import java.util.stream.StreamSupport;

import es.indra.interfaz.ItfzCalculadora;


public class AppMain {
	
	public static void main(String[] args) {
		ServiceLoader<ItfzCalculadora> loader = ServiceLoader.load(ItfzCalculadora.class);
		Iterable<ItfzCalculadora> iterable = () -> loader.iterator();
		ItfzCalculadora calculadora = StreamSupport.stream(iterable.spliterator(), false)
								.findFirst()
								.get();
		
		System.out.println("8 + 3 = " + calculadora.sumar(8, 3));
		System.out.println("8 - 3 = " + calculadora.restar(8, 3));
		System.out.println("8 * 3 = " + calculadora.multiplicar(8, 3));
		System.out.println("8 / 3 = " + calculadora.dividir(8, 3));
	}

}

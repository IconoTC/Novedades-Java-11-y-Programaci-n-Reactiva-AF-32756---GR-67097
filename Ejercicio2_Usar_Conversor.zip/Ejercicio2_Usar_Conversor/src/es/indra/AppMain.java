package es.indra;

import es.indra.business.Conversor;

public class AppMain {

	public static void main(String[] args) {
		
		Conversor conversor = new Conversor();
		
		System.out.println("1000 euros son " +
				conversor.euroToDollar(1000) + " dolares");
		
		System.out.println("1063.83 dolares " + 
				conversor.dollarToEuro(1063.83) + " euros");

	}

}

package es.indra.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import es.indra.business.AlumnosBS;
import es.indra.models.Alumno;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/api")  // http://localhost:8081/api
public class AlumnosREST {
	
	@Autowired
	private AlumnosBS bs;
	
	// http://localhost:8081/api/alumnos
	@GetMapping("/alumnos")
	public Flux<Alumno> todos(){
		return bs.consultarTodos();
	}
	
	// http://localhost:8081/api/alumnos/2
	@GetMapping("/alumnos/{id}")
	public Mono<Alumno> consultarAlumno(@PathVariable(name="id") int id){
		return bs.buscarAlumno(id);
	}
	
	// http://localhost:8081/api/alumnos
	@PostMapping("/alumnos")
	public Mono<Alumno> insertarAlumno(@RequestBody Alumno alumno){
		return bs.crearNuevo(alumno);
	}
	
	// http://localhost:8081/api/alumnos
	@PutMapping("/alumnos")
	public Mono<Alumno> modificarAlumno(@RequestBody Alumno alumno){
		return bs.modificarAlumno(alumno);
	}
	
	// http://localhost:8081/api/alumnos/2
	@DeleteMapping("/alumnos/{id}")
	public Mono<Void> borrarAlumno(@PathVariable(name="id") int id){
		return bs.eliminarAlumno(id);
	}

}

package es.indra.persistence;

import org.springframework.data.r2dbc.repository.R2dbcRepository;

import es.indra.models.Alumno;

// No necesito anotacion al ser un repositorio de Spring
public interface AlumnosDAO extends R2dbcRepository<Alumno, Integer> {
	
	
}

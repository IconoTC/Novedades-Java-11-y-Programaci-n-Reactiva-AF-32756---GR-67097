/**
 * 
 */
/**
 * 
 */
module Ejemplo05_Servicio_Consumidor {
	
	// Necesito el modulo donde esta declarada la interface
	requires Ejemplo03_Servicio_Interface;
	
	// Necesito indicar cual es la interface del servicio
	uses es.indra.interfaz.ItfzSaludo;
}
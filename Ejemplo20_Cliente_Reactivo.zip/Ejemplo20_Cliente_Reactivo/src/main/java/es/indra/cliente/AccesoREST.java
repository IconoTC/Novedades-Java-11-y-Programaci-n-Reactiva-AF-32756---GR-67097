package es.indra.cliente;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;

import es.indra.models.Alumno;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
public class AccesoREST {
	
	@Autowired
	private WebClient webClient;
	
	
	public Flux<Alumno> consultarTodos(){
		return webClient.get().uri("/alumnos")
				.retrieve()
				.bodyToFlux(Alumno.class);
	}
	
	public Mono<Alumno> crearNuevo(Alumno nuevo){
		return webClient.post().uri("/alumnos")
				.body(BodyInserters.fromValue(nuevo))
				.retrieve()
				.bodyToMono(Alumno.class);
	}

}

package es.indra.utils;

import java.util.Comparator;

import es.indra.models.Alumno;

public class ComparadorNota implements Comparator<Alumno>{

	@Override
	public int compare(Alumno alum1, Alumno alum2) {
		// 1 o cualquier positivo cuando alum1 > alum2
		// -1 o cualquier negativo cuando alum1 < alum2
		// 0 los dos son iguales
		if (alum1.getNota() > alum2.getNota()) {
			return 1;
		} else if (alum1.getNota() < alum2.getNota()) {
			return -1;
		}
		return 0;
	}

}

/**
 * 
 */
/**
 * 
 */
module Ejercicio4_Servicio_Calculadora_Proveedor {
	requires Ejercicio3_Servicio_Calculadora;
	provides es.indra.interfaz.ItfzCalculadora with es.indra.business.Calculadora;
}
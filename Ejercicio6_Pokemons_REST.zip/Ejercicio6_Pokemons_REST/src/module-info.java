/**
 * 
 */
/**
 * 
 */
module Ejercicio6_Pokemons_REST {
	
	requires java.net.http;
	requires org.json;
	
}
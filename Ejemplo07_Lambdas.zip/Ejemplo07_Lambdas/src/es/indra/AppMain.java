package es.indra;

import es.indra.business.ItfzEmpleados;

public class AppMain {

	public static void main(String[] args) {
		
		// Sintaxis: (parametros)   ->   {cuerpo del metodo}
		// Los parentesis son obligatorios: ponemos el tipo al parametro, cuando hay mas de un parametro
		// Las llaves son obligatorias: tenemos mas de 1 linea de codigo o le ponemos return
		
		ItfzEmpleados lambda1 = (nombre, edad) -> "Nombre: " + nombre + ", edad: " + edad;
		System.out.println(lambda1.detalle("Juan", 38));
		
		ItfzEmpleados lambda2 = (nombre, edad) -> {
			return "Nombre: " + nombre + ", edad: " + edad;
		};
		System.out.println(lambda2.detalle("Juan", 38));
		
		ItfzEmpleados lambda3 = (nombre, edad) -> {
			nombre = nombre.toUpperCase();
			edad += 1;
			return "Nombre: " + nombre + ", edad: " + edad;
		};
		System.out.println(lambda3.detalle("Juan", 38));
		
		// Los parametros no tienen porque llamarse igual que en la declaracion de la interface
		ItfzEmpleados lambda4 = (n, e) -> "Nombre: " + n + ", edad: " + e;
		System.out.println(lambda4.detalle("Juan", 38));
		
		// Podemos poner el tipo de dato
		ItfzEmpleados lambda5 = (String nombre, int edad) -> "Nombre: " + nombre + ", edad: " + edad;
		System.out.println(lambda5.detalle("Juan", 38));
		
		// Podemos utilizar inferencia de tipos en los parametros
		ItfzEmpleados lambda6 = (var nombre, var edad) -> "Nombre: " + nombre + ", edad: " + edad;
		System.out.println(lambda6.detalle("Juan", 38));

	}

}

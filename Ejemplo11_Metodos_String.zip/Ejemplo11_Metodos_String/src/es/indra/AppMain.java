package es.indra;

import java.util.List;
import java.util.stream.Collectors;

public class AppMain {

	public static void main(String[] args) {
		
		// isBlank
		System.out.println("Hola".isBlank());
		System.out.println(" ".isBlank());
		System.out.println("".isBlank());
		System.out.println("\t".isBlank());
		System.out.println("\n".isBlank());
		
		// repeat
		System.out.println("-".repeat(30));
		System.out.println("ja".repeat(5));
		
		// strip
		String nombre = "     Juan     ";
		System.out.println(nombre + ".");
		
		// Quiero eliminar los espacios por la derecha e izquierda
		System.out.println(nombre.strip() + ".");
		
		// Solo quiero quitar estacios por la derecha
		System.out.println(nombre.stripTrailing() + ".");
		
		// Solo quiero quitar estacios por la izquierda
		System.out.println(nombre.stripLeading() + ".");
		
		// lines
		String texto = "Hola\nque\ntal?\nmañana\nes viernes";
		System.out.println(texto);
		
		List<String> lista = texto.lines().collect(Collectors.toList());
		System.out.println(lista);
		
		texto.lines()
			.filter(dato -> dato.length() > 4)
			.map(dato -> dato.toUpperCase())
			.forEach(System.out::println);
			

	}

}

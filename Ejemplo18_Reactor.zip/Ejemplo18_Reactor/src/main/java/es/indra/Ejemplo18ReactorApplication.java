package es.indra;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ejemplo18ReactorApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ejemplo18ReactorApplication.class, args);
	}

}

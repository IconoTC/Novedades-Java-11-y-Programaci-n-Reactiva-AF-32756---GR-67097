/**
 * 
 */
/**
 * 
 */
module Ejercicio5_Servicio_Calculadora_Consumidor {
	
	requires Ejercicio3_Servicio_Calculadora;
	uses es.indra.interfaz.ItfzCalculadora;
}